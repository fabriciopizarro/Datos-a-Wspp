let sendBtn = document.getElementById('send-btn');

 sendBtn.addEventListener("click", () => {
  let msg = document.getElementById('whats-in').value;
  let relmsg = msg.replace(/ /g,"%20");
 let msg2 = document.getElementById('whats-in2').value;
let relmsg2 = msg2.replace(/ /g,"%20");
     
   window.open("https://wa.me/+51960116125?text="+'First Name: '+relmsg+'%20'+'Last Name: '+relmsg2); 
  
  });
